/*14.	Which of the given players have consistently performed well in past seasons?
 (will you use any visualisation to solve the problem) */
 
 
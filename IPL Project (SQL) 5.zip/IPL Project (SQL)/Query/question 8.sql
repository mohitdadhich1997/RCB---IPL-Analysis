/* 8.	List all the players who have average runs scored greater than 
overall average and who have taken wickets greater than overall average */

with cte1 as (select count(ball_id) as cns ,match_id from wicket_taken
group by match_id),
cte2 as (select match_id,Team_Bowling,bowler from ball_by_ball
           where team_bowling =2),
cte3 as (select match_id,count(ball_id)  as cnb from wicket_taken
group by match_id),
cte4 as (select match_id,player_id from player_match where team_id=2),
cte5 as (select player_id,player_name from player)

select distinct player_name,bowler,avg(cns) from cte1
join cte2 on cte1.match_id=cte2.match_id
join cte4 
on cte1.match_id=cte4.match_id
join cte5
on cte4.player_id=cte5.player_id
group by bowler,player_name          
having avg(cns)>(select avg(cnb) from cte3)
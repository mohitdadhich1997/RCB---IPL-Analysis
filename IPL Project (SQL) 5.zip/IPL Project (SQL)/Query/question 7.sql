/* 7.	What are the average wickets taken by each bowler considering all the seasons? */


with cte1 as (select count(match_id) as cnm,match_id from wicket_taken
              group by match_id),

cte2 as (select match_id,team_bowling,bowler from ball_by_ball
         where team_bowling=2 ),

cte3 as (select match_id,player_id,team_id from player_match
         where team_id=2),
cte4 as (select player_id,player_name from player 
		 where bowling_skill is not null )

select player_name,bowler,round(avg(cnm),2) as avg_wicket from cte1
join cte2 
on cte1.match_id=cte2.match_id
join cte3
on cte2.match_id=cte3.match_id
join cte4
on cte2.bowler=cte4.player_id
group by player_name,bowler


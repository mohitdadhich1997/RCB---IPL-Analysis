/* 11.	Write the sql query to provide a status of whether the performance of the team better than the previous year 
performance on the basis of number of runs scored by the team in the season and number of wickets taken */

	with cte1 as (select match_id,Innings_No,sum(Runs_Scored) as total_runs from batsman_scored 

	group by Innings_No,Match_Id),
	 
	 cte2 as (select Match_Id,ball_id from ball_by_ball where Team_Batting=2),
	 cte3 as (select match_id,season_id,Team_1,Team_2 from matches),
	 cte4 as (select match_id,sum(extra_runs) as extras from extra_runs
	 group by match_id)
	 
	 select season_id,sum(distinct total_runs + extras) as total_runs_scored from cte1
	 join cte2
	 on cte1.match_id=cte2.match_id
	 join cte3
	 on cte2.match_id=cte3.match_id
	 join cte4
	 on cte3.match_id=cte4.match_id
	 group by season_id;

    /* performance based on number of wickets taken */  
     
     with cte1 as (select match_id,team_bowling,bowler,innings_no from ball_by_ball
     where team_bowling=2),
     
     cte2 as (select match_id,innings_no,count(player_out) as wickets from wicket_taken
     group by match_id,innings_no),
     
     cte3 as (select match_id,season_id from matches)
	 
     select distinct season_id,round(avg(wickets)) from cte1
     join cte2
     on cte1.match_id=cte2.match_id
     join cte3
     on cte2.match_id=cte3.match_id
	 group by season_id

     
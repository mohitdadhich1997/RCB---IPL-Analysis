/* 6.	What is the average runs scored by each batsman considering all the seasons*/

with cte1 as (select distinct striker,match_id,team_batting,innings_no from ball_by_ball
where Team_Batting=2),

cte2 as (select match_id,avg(runs_scored) as total_score,innings_no from batsman_scored
group by innings_no,match_id),

cte3 as (select match_id,team_id,Player_Id from player_match
where team_id=2),
cte4 as (select player_id,player_name from player),
cte5 as (select match_id,season_id from matches)
select distinct striker,season_id,player_name,sum(total_score) as avg_runs_scored from cte1
join cte2
on cte1.match_id=cte2.match_id
join cte3
on cte1.striker=cte3.player_id
join cte4 
on cte3.player_id=cte4.player_id
join cte5
on cte3.match_id=cte5.match_id
group  by striker,season_id,player_name



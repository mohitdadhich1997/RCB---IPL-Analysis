
/* question 1. What is the total number of run scored in 1st season by RCB 
(bonus : also include the extra runs using the extra runs table)*/

with cte1 as (select match_id,Innings_No,sum(Runs_Scored) as total_runs from batsman_scored 

group by Innings_No,Match_Id),
 
 cte2 as (select Match_Id,ball_id from ball_by_ball where Team_Batting=2),
 cte3 as (select match_id,season_id,Team_1,Team_2 from matches),
 cte4 as (select match_id,sum(extra_runs) as extras from extra_runs
 group by match_id)
 
 select sum(distinct total_runs + extras) as total_runs_scored,innings_no from cte1
 join cte2
 on cte1.match_id=cte2.match_id
 join cte3
 on cte2.match_id=cte3.match_id
 join cte4
 on cte3.match_id=cte4.match_id
 where season_id=1
 group by innings_no
 order by innings_no asc;
 
 
 
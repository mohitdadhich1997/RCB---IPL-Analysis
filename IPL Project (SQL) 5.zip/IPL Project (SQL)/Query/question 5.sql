/* 5.	List top 10 players according to their strike rate in last 4 seasons */

with cte1 as (select match_id,Season_Id,year(match_date) from matches
where Season_Id in (9,8,7,6)
order by season_id asc),
cte2 as (select distinct match_id,Runs_Scored from batsman_scored ),
cte3 as (select distinct match_id,player_id,team_id from player_match
         where team_id=2),
cte4 as (select match_id,ball_id,Striker from ball_by_ball
where team_batting =2
),
cte5 as ( select player_id,player_name from player)


select distinct cte3.player_id,player_name, round (sum(runs_scored)/sum(cte4.ball_id)*100,2) as strike_rate ,season_id from cte1
join cte2
on cte1.match_id=cte2.match_id
join cte3
on cte2.match_id=cte3.match_id
join cte4 
on cte3.match_id=cte4.match_id
join cte5
on cte3.player_id=cte5.player_id
where season_id=7
group by player_id,season_id
order by strike_rate desc
limit 10 



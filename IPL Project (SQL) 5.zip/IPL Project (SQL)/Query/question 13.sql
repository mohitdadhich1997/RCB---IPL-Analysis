/* 13.	Using SQL, write a query to find out average wickets taken by each bowler in each venue. 
Also rank the gender according to the average value. */

with cte1 as (select count(match_id) as cnm,match_id from wicket_taken
              group by match_id),

cte2 as (select match_id,team_bowling,bowler from ball_by_ball
         where team_bowling=2 ),

cte3 as (select match_id,player_id,team_id from player_match
         where team_id=2),
cte4 as (select player_id,player_name from player 
		 where bowling_skill is not null ),
cte5 as (select match_id,venue_id from matches),
cte6 as (select venue_id,venue_name from venue)
select player_name,bowler,cte5.venue_id,venue_name,round(avg(cnm),2) as avg_wicket,dense_rank()over(partition by cte5.venue_id order by avg(cnm) desc ) as bowler_Rank from cte1
join cte2 
on cte1.match_id=cte2.match_id
join cte3
on cte2.match_id=cte3.match_id
join cte4
on cte2.bowler=cte4.player_id
join cte5
on cte3.match_id=cte5.match_id
join cte6
on cte5.venue_id=cte6.venue_id
group by player_name,bowler,venue_id,venue_name
order by venue_id asc
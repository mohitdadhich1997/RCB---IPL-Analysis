/* 3.	How many players were more than age of 25 during season 2 ? */

with cte1 as (select player_id,(2009-year(dob)) as age from player),
cte2 as ( select * from player_match where team_id=2)

select count(distinct cte1.player_id) as player_count from cte1
join cte2
on cte1.player_id=cte2.player_id
where age>25



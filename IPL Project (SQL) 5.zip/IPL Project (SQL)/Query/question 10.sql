/* 10.	What is the impact of bowling style on wickets taken. */

select* from bowling_style;

with cte1 as (select match_id,bowler,team_bowling from ball_by_ball
where team_bowling=2),

cte2 as (select p.player_id,p.bowling_skill as pbs,bs.bowling_skill as bsbs from player p
join bowling_style bs
on p.Bowling_skill=bs.Bowling_Id
where p.Bowling_skill is not null),

cte3 as (select * from player_match
where team_id=2)

select distinct bowler,pbs,bsbs from cte1 
join cte2 
on cte1.bowler=cte2.player_id
join cte3
on cte2.player_id=cte3.player_id


select * from wicket_taken;
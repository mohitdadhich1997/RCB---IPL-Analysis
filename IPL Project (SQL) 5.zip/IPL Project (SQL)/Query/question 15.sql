/* 15.	Are there players whose performance is more suited to specific venues or conditions?
 (how would you present this using charts?) */
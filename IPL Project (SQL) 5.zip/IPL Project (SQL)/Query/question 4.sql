/*4.	How many matches did RCB win in season 1 ? */
	
select * from matches
where match_winner=2 and season_id=1

